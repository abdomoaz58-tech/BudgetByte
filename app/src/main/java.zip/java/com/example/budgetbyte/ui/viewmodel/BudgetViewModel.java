package com.example.budgetbyte.ui.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.budgetbyte.data.entity.CategoryStat;
import com.example.budgetbyte.data.repository.ExpenseRepository;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class BudgetViewModel extends AndroidViewModel {
    private final ExpenseRepository repository;
    private final MutableLiveData<List<CategoryStat>> categories = new MutableLiveData<>(Collections.emptyList());

    public BudgetViewModel(@NonNull Application app) {
        super(app);
        repository = new ExpenseRepository(app);
        loadCurrentMonth();
    }

    public LiveData<List<CategoryStat>> categories() {
        return categories;
    }

    public void loadCurrentMonth() {
        loadForMonth(new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date()));
    }

    public void loadForMonth(String yearMonth) {
        String monthKey = yearMonth == null || yearMonth.trim().isEmpty()
                ? new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date())
                : yearMonth;

        repository.getCategoryStats(monthKey).observeForever(items ->
                categories.postValue(items == null ? Collections.emptyList() : items));
    }

    @Override
    protected void onCleared() {
        repository.close();
    }
}
