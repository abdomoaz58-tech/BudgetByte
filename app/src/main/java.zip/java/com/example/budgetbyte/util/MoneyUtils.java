package com.example.budgetbyte.util;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Locale;

/** Utility methods for amounts persisted as minor currency units. */
public final class MoneyUtils {
    private static final BigDecimal MINOR_UNIT_SCALE = BigDecimal.valueOf(100L);

    private MoneyUtils() { }

    /** Converts a major-unit amount, such as 10.50, to persisted minor units (1050). */
    public static long toMinorUnits(double amount) {
        if (!Double.isFinite(amount)) {
            throw new IllegalArgumentException("Amount must be finite");
        }
        return BigDecimal.valueOf(amount)
                .movePointRight(2)
                .setScale(0, RoundingMode.HALF_UP)
                .longValueExact();
    }

    /** Converts persisted minor units, such as 1050, to a major-unit amount (10.50). */
    public static double toMajorUnits(long minorUnits) {
        return BigDecimal.valueOf(minorUnits).divide(MINOR_UNIT_SCALE).doubleValue();
    }

    /** Convenience overload for the default currency. */
    public static String formatAmount(long minorUnits) {
        return formatAmount(minorUnits, "EGP");
    }

    /** Formats a persisted minor-unit amount using integer division to avoid floating-point display math. */
    public static String formatAmount(long minorUnits, String currencyCode) {
        String code = currencyCode == null || currencyCode.trim().isEmpty()
                ? "EGP" : currencyCode.trim().toUpperCase(Locale.ROOT);

        long absoluteMinorUnits = Math.abs(minorUnits);
        long units = absoluteMinorUnits / 100L;
        long cents = absoluteMinorUnits % 100L;
        String sign = minorUnits < 0 ? "-" : "";

        return String.format(Locale.US, "%s%d.%02d %s", sign, units, cents, code);
    }
}
