package com.example.budgetbyte.ui.budget;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.budgetbyte.R;
import com.example.budgetbyte.data.entity.CategoryStat;
import com.example.budgetbyte.databinding.FragmentBudgetBinding;
import com.example.budgetbyte.ui.viewmodel.BudgetViewModel;
import com.example.budgetbyte.ui.viewmodel.SelectedMonthViewModel;
import com.example.budgetbyte.util.MoneyUtils;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;

public class BudgetFragment extends Fragment {
    private FragmentBudgetBinding binding;
    private BudgetViewModel viewModel;
    private SelectedMonthViewModel selectedMonthViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentBudgetBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        viewModel = new ViewModelProvider(this).get(BudgetViewModel.class);
        selectedMonthViewModel = new ViewModelProvider(requireActivity()).get(SelectedMonthViewModel.class);
        selectedMonthViewModel.setCurrentMonth();

        binding.btnPrevMonth.setOnClickListener(v -> selectedMonthViewModel.shiftMonth(-1));
        binding.btnNextMonth.setOnClickListener(v -> selectedMonthViewModel.shiftMonth(1));

        selectedMonthViewModel.selectedMonth().observe(getViewLifecycleOwner(), month -> {
            Calendar calendar = Calendar.getInstance(Locale.getDefault());
            calendar.clear();
            calendar.set(month.year, month.month - 1, 1);
            binding.tvSelectedMonth.setText(new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(calendar.getTime()));
            viewModel.loadForMonth(month.toYearMonthString());
        });

        viewModel.categories().observe(getViewLifecycleOwner(), this::renderCategoryBreakdown);
    }

    private void renderCategoryBreakdown(List<CategoryStat> items) {
        binding.budgetCategoryList.removeAllViews();

        long total = 0L;
        if (items != null) {
            for (CategoryStat item : items) {
                if (item != null) {
                    total += item.total;
                }
            }
        }

        binding.tvBudgetSummary.setText(MoneyUtils.formatAmount(total, "EGP"));

        if (items == null || items.isEmpty()) {
            binding.budgetCategoryEmpty.setVisibility(View.VISIBLE);
            binding.budgetCategoryList.setVisibility(View.GONE);
            return;
        }

        binding.budgetCategoryEmpty.setVisibility(View.GONE);
        binding.budgetCategoryList.setVisibility(View.VISIBLE);

        long grandTotal = total > 0 ? total : 1L;
        for (CategoryStat item : items) {
            if (item == null || item.category == null || item.category.trim().isEmpty()) {
                continue;
            }

            long amount = item.total;
            int percent = (int) Math.round((amount * 100d) / grandTotal);
            View row = LayoutInflater.from(requireContext())
                    .inflate(R.layout.item_budget_category, binding.budgetCategoryList, false);

            TextView title = row.findViewById(R.id.tvBudgetCategoryName);
            TextView value = row.findViewById(R.id.tvBudgetCategoryAmount);
            TextView pct = row.findViewById(R.id.tvBudgetCategoryPercent);
            ProgressBar progressBar = row.findViewById(R.id.progressBudgetCategory);
            View dot = row.findViewById(R.id.viewBudgetCategoryDot);

            title.setText(item.category);
            value.setText(MoneyUtils.formatAmount(amount, "EGP"));
            pct.setText(String.format(Locale.getDefault(), "%d%%", percent));
            progressBar.setProgress(Math.min(100, percent));
            dot.setBackgroundTintList(ContextCompat.getColorStateList(requireContext(), R.color.primary));

            binding.budgetCategoryList.addView(row);
        }
    }

    @Override
    public void onDestroyView() {
        binding = null;
        super.onDestroyView();
    }
}
