package com.example.budgetbyte.ui.history;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.fragment.NavHostFragment;
import androidx.recyclerview.widget.ItemTouchHelper;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.budgetbyte.R;
import com.example.budgetbyte.databinding.FragmentTransactionsBinding;
import com.example.budgetbyte.ui.common.ExpenseAdapter;
import com.example.budgetbyte.ui.viewmodel.TransactionsViewModel;

public class TransactionsFragment extends Fragment {
    private FragmentTransactionsBinding binding;
    private TransactionsViewModel viewModel;
    private ExpenseAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentTransactionsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        viewModel = new ViewModelProvider(this).get(TransactionsViewModel.class);
        adapter = new ExpenseAdapter();

        binding.rvTransactions.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.rvTransactions.setAdapter(adapter);

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (root, insets) -> {
            Insets statusBars = insets.getInsets(WindowInsetsCompat.Type.statusBars());
            Insets navBars = insets.getInsets(WindowInsetsCompat.Type.navigationBars());
            root.setPadding(statusBars.left + 16, statusBars.top + 16, statusBars.right + 16,
                    navBars.bottom + 16);
            return insets;
        });

        adapter.setOnItemClickListener(expense -> {
            Bundle args = new Bundle();
            args.putLong("expenseId", expense.getId());
            args.putString("transactionType", expense.getType() == null || expense.getType().trim().isEmpty() ? "expense" : expense.getType());
            args.putString("type", args.getString("transactionType"));
            args.putString("title", expense.getTitle());
            args.putLong("amount", expense.getAmount());
            args.putString("category", expense.getCategory());
            args.putString("date", expense.getDate());
            NavHostFragment.findNavController(this).navigate(R.id.action_global_addExpenseFragment, args);
        });

        viewModel.expenses().observe(getViewLifecycleOwner(), adapter::submitList);

        new ItemTouchHelper(new ItemTouchHelper.SimpleCallback(0, ItemTouchHelper.LEFT | ItemTouchHelper.RIGHT) {
            @Override
            public boolean onMove(@NonNull RecyclerView recyclerView, @NonNull RecyclerView.ViewHolder viewHolder,
                                  @NonNull RecyclerView.ViewHolder target) {
                return false;
            }

            @Override
            public void onSwiped(@NonNull RecyclerView.ViewHolder viewHolder, int direction) {
                int position = viewHolder.getBindingAdapterPosition();
                if (position != RecyclerView.NO_POSITION) {
                    viewModel.delete(adapter.getExpenseAt(position));
                }
            }
        }).attachToRecyclerView(binding.rvTransactions);
    }

    @Override
    public void onDestroyView() {
        binding = null;
        super.onDestroyView();
    }
}
