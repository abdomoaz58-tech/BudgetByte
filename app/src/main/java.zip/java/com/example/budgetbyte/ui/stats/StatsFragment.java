package com.example.budgetbyte.ui.stats;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.budgetbyte.R;
import com.example.budgetbyte.data.entity.CategoryStat;
import com.example.budgetbyte.databinding.FragmentStatsBinding;
import com.example.budgetbyte.ui.viewmodel.SelectedMonthViewModel;
import com.example.budgetbyte.ui.viewmodel.StatsViewModel;
import com.example.budgetbyte.util.MoneyUtils;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class StatsFragment extends Fragment {
    private FragmentStatsBinding binding;
    private StatsViewModel viewModel;
    private SelectedMonthViewModel selectedMonthViewModel;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentStatsBinding.inflate(inflater, container, false);
        return binding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        viewModel = new ViewModelProvider(this).get(StatsViewModel.class);
        selectedMonthViewModel = new ViewModelProvider(requireActivity()).get(SelectedMonthViewModel.class);
        selectedMonthViewModel.setCurrentMonth();

        ViewCompat.setOnApplyWindowInsetsListener(binding.getRoot(), (root, insets) -> {
            Insets statusBars = insets.getInsets(WindowInsetsCompat.Type.statusBars());
            Insets navBars = insets.getInsets(WindowInsetsCompat.Type.navigationBars());
            root.setPadding(statusBars.left + 16, statusBars.top + 16, statusBars.right + 16,
                    navBars.bottom + 16);
            return insets;
        });

        binding.btnPrevMonth.setOnClickListener(v -> selectedMonthViewModel.shiftMonth(-1));
        binding.btnNextMonth.setOnClickListener(v -> selectedMonthViewModel.shiftMonth(1));

        selectedMonthViewModel.selectedMonth().observe(getViewLifecycleOwner(), month -> {
            binding.tvSelectedMonth.setText(formatMonthLabel(month.year, month.month));
            viewModel.loadForMonth(month.toYearMonthString());
        });

        viewModel.currentMonthSpending().observe(getViewLifecycleOwner(), this::renderCurrentMonthSummary);
        viewModel.categoryBreakdown().observe(getViewLifecycleOwner(), this::renderCategoryBreakdown);
        viewModel.monthlyTotals().observe(getViewLifecycleOwner(), this::renderMonthlyHistory);
    }

    private void renderCurrentMonthSummary(Long total) {
        long totalValue = total == null ? 0L : total;
        binding.tvMonthTotal.setText(MoneyUtils.formatAmount(totalValue, "EGP"));
    }

    private void renderCategoryBreakdown(List<CategoryStat> items) {
        binding.categoryLegend.removeAllViews();
        if (items == null || items.isEmpty()) {
            binding.categoryEmpty.setVisibility(View.VISIBLE);
            binding.categoryLegend.setVisibility(View.GONE);
            binding.pieChart.setVisibility(View.GONE);
            binding.tvInsight.setText(getString(R.string.insight_empty));
            return;
        }

        long total = StatsAnalysisUtils.totalForSet(items);
        binding.categoryEmpty.setVisibility(View.GONE);
        binding.categoryLegend.setVisibility(View.VISIBLE);
        binding.pieChart.setVisibility(View.VISIBLE);

        if (total <= 0L) {
            binding.pieChart.clear();
            binding.tvInsight.setText(getString(R.string.insight_empty));
            return;
        }

        List<PieEntry> pieEntries = new ArrayList<>();
        List<Integer> colors = new ArrayList<>();
        int[] palette = new int[] {
                ContextCompat.getColor(requireContext(), R.color.primary_blue),
                ContextCompat.getColor(requireContext(), R.color.burgundy),
                ContextCompat.getColor(requireContext(), R.color.primary_blue_dark),
                ContextCompat.getColor(requireContext(), R.color.burgundy_dark),
                ContextCompat.getColor(requireContext(), R.color.text_secondary),
                ContextCompat.getColor(requireContext(), R.color.primary_blue),
                ContextCompat.getColor(requireContext(), R.color.burgundy),
                ContextCompat.getColor(requireContext(), R.color.text_secondary)
        };

        CategoryStat top = null;
        for (CategoryStat item : items) {
            if (item == null) {
                continue;
            }
            if (top == null || item.total > top.total) {
                top = item;
            }
            pieEntries.add(new PieEntry(item.total, item.category == null || item.category.trim().isEmpty() ? "Other" : item.category));
            colors.add(palette[colors.size() % palette.length]);
        }

        PieDataSet pieDataSet = new PieDataSet(pieEntries, "");
        pieDataSet.setColors(colors);
        pieDataSet.setDrawValues(false);
        pieDataSet.setSliceSpace(3f);
        pieDataSet.setSelectionShift(4f);
        PieData pieData = new PieData(pieDataSet);

        PieChart pieChart = binding.pieChart;
        pieChart.setUsePercentValues(false);
        pieChart.setDrawEntryLabels(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleRadius(54f);
        pieChart.setTransparentCircleRadius(58f);
        pieChart.setCenterText(MoneyUtils.formatAmount(total, "EGP"));
        pieChart.setCenterTextSize(14f);
        pieChart.setCenterTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary));
        pieChart.getDescription().setEnabled(false);
        pieChart.getLegend().setEnabled(false);
        pieChart.setRotationEnabled(false);
        pieChart.setHighlightPerTapEnabled(false);
        pieChart.setTouchEnabled(false);
        pieChart.setData(pieData);
        pieChart.invalidate();

        int[] legendPalette = new int[] {
                ContextCompat.getColor(requireContext(), R.color.primary),
                ContextCompat.getColor(requireContext(), R.color.secondary),
                ContextCompat.getColor(requireContext(), R.color.primary_container),
                ContextCompat.getColor(requireContext(), R.color.secondary_container),
                ContextCompat.getColor(requireContext(), R.color.on_surface_variant),
                ContextCompat.getColor(requireContext(), R.color.primary)
        };

        for (int i = 0; i < items.size(); i++) {
            CategoryStat item = items.get(i);
            if (item == null) {
                continue;
            }
            int percent = StatsAnalysisUtils.calculatePercent(item.total, total);
            String categoryName = (item.category == null || item.category.trim().isEmpty()) ? "Other" : item.category;

            LinearLayout row = new LinearLayout(requireContext());
            row.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setGravity(android.view.Gravity.CENTER_VERTICAL);
            row.setPadding(0, 8, 0, 8);

            View dot = new View(requireContext());
            LinearLayout.LayoutParams dotParams = new LinearLayout.LayoutParams(
                    dpToPx(8), dpToPx(8));
            dotParams.setMargins(0, 0, dpToPx(8), 0);
            dot.setLayoutParams(dotParams);
            dot.setBackgroundColor(legendPalette[i % legendPalette.length]);
            row.addView(dot);

            TextView title = new TextView(requireContext());
            title.setLayoutParams(new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
            title.setText(categoryName);
            title.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_primary));
            title.setTextSize(14f);
            row.addView(title);

            TextView amount = new TextView(requireContext());
            amount.setLayoutParams(new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            amount.setText(MoneyUtils.formatAmount(item.total, "EGP"));
            amount.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary));
            amount.setTextSize(12f);
            row.addView(amount);

            TextView percentView = new TextView(requireContext());
            LinearLayout.LayoutParams percentParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            percentParams.setMargins(dpToPx(8), 0, 0, 0);
            percentView.setLayoutParams(percentParams);
            percentView.setText(String.format(Locale.getDefault(), "%d%%", percent));
            percentView.setTextColor(ContextCompat.getColor(requireContext(), R.color.primary));
            percentView.setTextSize(12f);
            row.addView(percentView);

            binding.categoryLegend.addView(row);
        }

        if (top != null) {
            String insight = StatsAnalysisUtils.buildCategoryInsight(top.category, top.total, total);
            binding.tvInsight.setText(insight.isEmpty() ? getString(R.string.insight_empty) : insight);
        } else {
            binding.tvInsight.setText(getString(R.string.insight_empty));
        }
    }

    private void renderMonthlyHistory(List<CategoryStat> items) {
        if (items == null || items.isEmpty()) {
            binding.barChart.setVisibility(View.GONE);
            binding.barEmpty.setVisibility(View.VISIBLE);
            return;
        }

        List<CategoryStat> sorted = StatsAnalysisUtils.limitLastSix(items);
        binding.barChart.setVisibility(View.VISIBLE);
        binding.barEmpty.setVisibility(View.GONE);

        if (sorted.isEmpty()) {
            binding.barChart.clear();
            binding.barEmpty.setVisibility(View.VISIBLE);
            return;
        }

        List<BarEntry> values = new ArrayList<>();
        List<String> labels = new ArrayList<>();
        for (int i = 0; i < sorted.size(); i++) {
            CategoryStat item = sorted.get(i);
            if (item == null) {
                continue;
            }
            values.add(new BarEntry(i, item.total));
            labels.add(formatMonthLabel(item.category));
        }

        BarDataSet dataSet = new BarDataSet(values, "");
        int[] palette = new int[] {
                ContextCompat.getColor(requireContext(), R.color.primary),
                ContextCompat.getColor(requireContext(), R.color.primary_container),
                ContextCompat.getColor(requireContext(), R.color.primary_fixed),
                ContextCompat.getColor(requireContext(), R.color.secondary_container),
                ContextCompat.getColor(requireContext(), R.color.surface_container_high),
                ContextCompat.getColor(requireContext(), R.color.primary)
        };
        List<Integer> paletteList = new ArrayList<>();
        for (int i = 0; i < sorted.size(); i++) {
            paletteList.add(i == sorted.size() - 1
                    ? ContextCompat.getColor(requireContext(), R.color.primary)
                    : ContextCompat.getColor(requireContext(), R.color.surface_container_high));
        }
        dataSet.setColors(paletteList);
        dataSet.setValueTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary));
        dataSet.setDrawValues(false);

        BarChart barChart = binding.barChart;
        barChart.setData(new BarData(dataSet));
        barChart.getDescription().setEnabled(false);
        barChart.setFitBars(true);
        barChart.setTouchEnabled(false);
        barChart.setScaleEnabled(false);
        barChart.getLegend().setEnabled(false);
        barChart.getAxisRight().setEnabled(false);
        barChart.getAxisLeft().setAxisMinimum(0f);
        barChart.getAxisLeft().setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary));
        XAxis xAxis = barChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setLabelRotationAngle(-25f);
        xAxis.setTextColor(ContextCompat.getColor(requireContext(), R.color.text_secondary));
        xAxis.setValueFormatter(new IndexAxisValueFormatter(labels));
        xAxis.setLabelCount(Math.min(labels.size(), 6));
        xAxis.setAvoidFirstLastClipping(false);
        barChart.invalidate();
    }

    private int dpToPx(int dp) {
        return Math.round(dp * getResources().getDisplayMetrics().density);
    }

    private String formatMonthLabel(int year, int month) {
        Calendar calendar = Calendar.getInstance(Locale.getDefault());
        calendar.clear();
        calendar.set(year, month - 1, 1);
        return new SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(calendar.getTime());
    }

    private String formatMonthLabel(String yearMonth) {
        if (yearMonth == null || yearMonth.trim().isEmpty()) {
            return "";
        }
        try {
            Date parsed = new SimpleDateFormat("yyyy-MM", Locale.US).parse(yearMonth);
            if (parsed == null) {
                return yearMonth;
            }
            return new SimpleDateFormat("MMM yyyy", Locale.getDefault()).format(parsed);
        } catch (ParseException e) {
            return yearMonth;
        }
    }

    @Override
    public void onDestroyView() {
        binding = null;
        super.onDestroyView();
    }
}
