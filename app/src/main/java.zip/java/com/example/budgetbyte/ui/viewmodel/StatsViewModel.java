package com.example.budgetbyte.ui.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.example.budgetbyte.data.entity.CategoryStat;
import com.example.budgetbyte.data.repository.ExpenseRepository;
import com.example.budgetbyte.ui.stats.StatsAnalysisUtils;

import java.text.SimpleDateFormat;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class StatsViewModel extends AndroidViewModel {
    private final ExpenseRepository repository;
    private final MutableLiveData<Long> currentMonthSpending = new MutableLiveData<>(0L);
    private final MutableLiveData<List<CategoryStat>> categoryBreakdown = new MutableLiveData<>(Collections.emptyList());
    private final MutableLiveData<List<CategoryStat>> monthlyTotals = new MutableLiveData<>(Collections.emptyList());

    public StatsViewModel(@NonNull Application app) {
        super(app);
        repository = new ExpenseRepository(app);
    }

    public LiveData<Long> currentMonthSpending() {
        return currentMonthSpending;
    }

    public LiveData<List<CategoryStat>> categoryBreakdown() {
        return categoryBreakdown;
    }

    public LiveData<List<CategoryStat>> monthlyTotals() {
        return monthlyTotals;
    }

    public void loadCurrentMonthSpending() {
        loadForMonth(new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date()));
    }

    public void loadCategoryBreakdown() {
        loadForMonth(new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date()));
    }

    public void loadMonthlyTotals() {
        loadForMonth(new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date()));
    }

    public void loadForMonth(String yearMonth) {
        String monthKey = yearMonth == null || yearMonth.trim().isEmpty()
                ? new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date())
                : yearMonth;

        repository.getMonthlyExpenses(monthKey).observeForever(value ->
                currentMonthSpending.postValue(value == null ? 0L : value));
        repository.getCategoryStats(monthKey).observeForever(items ->
                categoryBreakdown.postValue(items == null ? Collections.emptyList() : items));

        repository.getMonthlyTotals("expense", 6, new ExpenseRepository.ResultCallback<List<CategoryStat>>() {
            @Override
            public void onResult(List<CategoryStat> result) {
                monthlyTotals.postValue(StatsAnalysisUtils.limitLastSix(result));
            }

            @Override
            public void onError(Exception exception) {
                monthlyTotals.postValue(Collections.emptyList());
            }
        });
    }

    @Override
    protected void onCleared() {
        repository.close();
    }
}
