package com.example.budgetbyte.ui.viewmodel;

import android.app.Application;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;

import com.example.budgetbyte.data.entity.Expense;
import com.example.budgetbyte.data.repository.ExpenseRepository;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeViewModel extends AndroidViewModel {
    private final ExpenseRepository repository;
    private final MediatorLiveData<Long> balance = new MediatorLiveData<>();
    private final String currentMonth;
    private long income;
    private long expense;

    public HomeViewModel(@NonNull Application application) {
        super(application);
        repository = new ExpenseRepository(application);
        currentMonth = new SimpleDateFormat("yyyy-MM", Locale.US).format(new Date());
        balance.addSource(repository.getMonthlyIncome(currentMonth), value -> {
            income = value == null ? 0L : value;
            balance.setValue(income - expense);
        });
        balance.addSource(repository.getMonthlyExpenses(currentMonth), value -> {
            expense = value == null ? 0L : value;
            balance.setValue(income - expense);
        });
    }

    public LiveData<List<Expense>> recentExpenses() {
        return repository.getRecentExpenses(5);
    }

    public LiveData<Long> balance() {
        return balance;
    }

    public LiveData<Long> monthlyIncome() {
        return repository.getMonthlyIncome(currentMonth);
    }

    public LiveData<Long> monthlyExpenses() {
        return repository.getMonthlyExpenses(currentMonth);
    }

    public void insert(Expense expense) {
        repository.insert(expense);
    }

    public void delete(Expense expense) {
        repository.delete(expense);
    }

    @Override
    protected void onCleared() {
        repository.close();
    }
}
