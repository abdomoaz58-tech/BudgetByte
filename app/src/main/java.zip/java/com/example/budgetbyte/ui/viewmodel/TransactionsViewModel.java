package com.example.budgetbyte.ui.viewmodel;

import android.app.Application;
import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;
import androidx.lifecycle.MediatorLiveData;
import androidx.lifecycle.MutableLiveData;
import com.example.budgetbyte.data.entity.Expense;
import com.example.budgetbyte.data.repository.ExpenseRepository;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class TransactionsViewModel extends AndroidViewModel {
    private final ExpenseRepository repository;
    private final MutableLiveData<String> filter = new MutableLiveData<>("");
    private final MediatorLiveData<List<Expense>> filteredExpenses = new MediatorLiveData<>();
    private List<Expense> allExpenses = new ArrayList<>();
    public TransactionsViewModel(@NonNull Application application) {
        super(application); repository = new ExpenseRepository(application);
        filteredExpenses.addSource(repository.getAllExpenses(), value -> { allExpenses = value == null ? new ArrayList<>() : value; applyFilter(); });
        filteredExpenses.addSource(filter, value -> applyFilter());
    }
    public LiveData<List<Expense>> expenses() { return filteredExpenses; }
    public LiveData<String> filter() { return filter; }
    public void setFilter(String value) { filter.setValue(value == null ? "" : value); }
    public void delete(Expense expense) { repository.delete(expense); }
    private void applyFilter() { String query = filter.getValue() == null ? "" : filter.getValue().trim().toLowerCase(Locale.ROOT); List<Expense> result = new ArrayList<>(); for (Expense item : allExpenses) if (query.isEmpty() || (item.title != null && item.title.toLowerCase(Locale.ROOT).contains(query))) result.add(item); filteredExpenses.setValue(result); }
    @Override protected void onCleared() { repository.close(); }
}
